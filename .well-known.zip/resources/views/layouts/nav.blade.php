
    <div id="accordion">
        <ul class="nav flex-column">

            @role('Sales')
            <li class="nav-item {{ (request()->is('admin')) ? 'active' : '' }}">
                <a href="{{ route('admin.index') }}" class="nav-link">
                    <span class="svg-icon nav-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20px" height="20px"
                            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                            stroke-linecap="round" stroke-linejoin="round" class="feather feather-home">
                            <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                            <polyline points="9 22 9 12 15 12 15 22"></polyline>
                        </svg>
                    </span>
                    <span class="nav-text">
                        Dashboard
                    </span>
                </a>
            </li>

            <li class="nav-item  {{ (request()->is('sales')) ? 'active' : '' }}">
                <a href="/sales" class="nav-link">
                    <span class="svg-icon nav-icon">
                        <i class="fas fa-clipboard-check font-size-h4" ></i>
                    </span>
                    <span class="nav-text">
                        Sales
                    </span>
                </a>
            </li>
            <li class="nav-item  {{ (request()->is('outstandings')) ? 'active' : '' }}">
                <a href="/outstandings" class="nav-link">
                    <span class="svg-icon nav-icon">
                        <i class="fas fa-arrow-right font-size-h4" ></i>
                    </span>
                    <span class="nav-text">
                        Outstanding
                    </span>
                </a>
            </li>

            <li class="nav-item {{ (request()->is('my-stock')) ? 'active' : '' }}">
                <a href="/my-stock" class="nav-link">
                    <span class="svg-icon nav-icon">
                        <i class="fas fa-money-bill font-size-h4"></i>
                    </span>
                    <span class="nav-text">
                        Stocks
                    </span>
                </a>
            </li>
            @endrole

            @role('Admin')
            <li class="nav-item {{ (request()->is('admin')) ? 'active' : '' }}">
                <a href="/admin" class="nav-link">
                    <span class="svg-icon nav-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20px" height="20px"
                            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                            stroke-linecap="round" stroke-linejoin="round" class="feather feather-home">
                            <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                            <polyline points="9 22 9 12 15 12 15 22"></polyline>
                        </svg>
                    </span>
                    <span class="nav-text">
                        Dashboard
                    </span>
                </a>
            </li>
            @endrole
        @role('Admin|Store')
        <li class="nav-item
        {{ (request()->is('stock-purchase')) ? 'active' : '' }}
        ">
        <a href="/stock-purchase" class="nav-link sub-nav-link {{ (request()->is('stock-purchase')) ? 'active' : '' }}">
            <span class="svg-icon nav-icon">
                <i class="fas fa-list font-size-h4"></i>
            </span>
            <span class="nav-text">Purchases</span>
        </a>
        </li>

      <li class="nav-item {{ (request()->is('stock-rent')) ? 'active' : '' }} {{ (request()->is('rent-items')) ? 'active' : '' }}">
            <a  class="nav-link" data-toggle="collapse" href="#rental" role="button"
            aria-expanded="false" aria-controls="rental">
                <span class="svg-icon nav-icon">
                    <i class="fas fa-check font-size-h4"></i>
                </span>
                <span class="nav-text">Rental</span>
                <i class="fas fa-chevron-right fa-rotate-90"></i>
            </a>
            <div class="collapse nav-collapse {{ (request()->is('stock-rent')) ? 'show' : '' }}
                {{ (request()->is('rent-items')) ? 'show' : '' }}
                " id="rental" data-parent="#accordion">
                <ul class="nav flex-column">

                    <li class="nav-item {{ (request()->is('stock-rent')) ? 'sub-active' : '' }}">
                        <a href="/stock-rent" class="nav-link sub-nav-link {{ (request()->is('stock-rent')) ? 'active' : '' }}">
                            <span class="svg-icon nav-icon d-flex justify-content-center">
                                <svg xmlns="http://www.w3.org/2000/svg" width="10px" height="10px" fill="currentColor" class="bi bi-circle" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                                  </svg>
                            </span>
                            <span class="nav-text">Renting</span>
                        </a>
                    </li>

                    <li class="nav-item {{ (request()->is('rent-items')) ? 'sub-active' : '' }}">
                        <a href="/rent-items" class="nav-link sub-nav-link {{ (request()->is('rent-items')) ? 'active' : '' }}">
                            <span class="svg-icon nav-icon d-flex justify-content-center">
                                <svg xmlns="http://www.w3.org/2000/svg" width="10px" height="10px" fill="currentColor" class="bi bi-circle" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                                  </svg>
                            </span>
                            <span class="nav-text">Renting Item </span>
                        </a>
                    </li>
                </ul>
            </div>
        </li>

        <li class="nav-item {{ (request()->is('sales')) ? 'active' : '' }} {{ (request()->is('outstandings')) ? 'active' : '' }}">
            <a  class="nav-link" data-toggle="collapse" href="#sales" role="button"
            aria-expanded="false" aria-controls="sales">
                <span class="svg-icon nav-icon">
                    <i class="fas fa-money-bill font-size-h4"></i>
                </span>
                <span class="nav-text">Sales</span>
                <i class="fas fa-chevron-right fa-rotate-90"></i>
            </a>
            <div class="collapse nav-collapse {{ (request()->is('sales')) ? 'show' : '' }}
                {{ (request()->is('outstandings')) ? 'show' : '' }}
                " id="sales" data-parent="#accordion">
                <ul class="nav flex-column">

                    <li class="nav-item {{ (request()->is('sales')) ? 'sub-active' : '' }}">
                        <a href="/sales" class="nav-link sub-nav-link {{ (request()->is('sales')) ? 'active' : '' }}">
                            <span class="svg-icon nav-icon d-flex justify-content-center">
                                <svg xmlns="http://www.w3.org/2000/svg" width="10px" height="10px" fill="currentColor" class="bi bi-circle" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                                  </svg>
                            </span>
                            <span class="nav-text">Sales List</span>
                        </a>
                    </li>

                    <li class="nav-item {{ (request()->is('outstandings')) ? 'sub-active' : '' }}">
                        <a href="/outstandings" class="nav-link sub-nav-link {{ (request()->is('outstandings')) ? 'active' : '' }}">
                            <span class="svg-icon nav-icon d-flex justify-content-center">
                                <svg xmlns="http://www.w3.org/2000/svg" width="10px" height="10px" fill="currentColor" class="bi bi-circle" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                                  </svg>
                            </span>
                            <span class="nav-text">Outstandings</span>
                        </a>
                    </li>
                </ul>
            </div>
        </li>

            <li class="nav-item {{ (request()->is('stocking')) ? 'active' : '' }} {{ (request()->is('stores')) ? 'active' : '' }}">
                <a  class="nav-link" data-toggle="collapse" href="#stock" role="button"
                aria-expanded="false" aria-controls="stock">
                    <span class="svg-icon nav-icon">
                        <i class="fas fa-money-bill font-size-h4"></i>
                    </span>
                    <span class="nav-text">Stock</span>
                    <i class="fas fa-chevron-right fa-rotate-90"></i>
                </a>
                <div class="collapse nav-collapse {{ (request()->is('stocking')) ? 'show' : '' }}
                    {{ (request()->is('stores')) ? 'show' : '' }}
                    " id="stock" data-parent="#accordion">
                    <ul class="nav flex-column">

                        <li class="nav-item {{ (request()->is('stocking')) ? 'sub-active' : '' }}">
                            <a href="/stocking" class="nav-link sub-nav-link {{ (request()->is('stocking')) ? 'active' : '' }}">
                                <span class="svg-icon nav-icon d-flex justify-content-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="10px" height="10px" fill="currentColor" class="bi bi-circle" viewBox="0 0 16 16">
                                        <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                                      </svg>
                                </span>
                                <span class="nav-text">Issue Stock</span>
                            </a>
                        </li>

                        <li class="nav-item {{ (request()->is('stores')) ? 'sub-active' : '' }}">
                            <a href="/stores" class="nav-link sub-nav-link {{ (request()->is('stores')) ? 'active' : '' }}">
                                <span class="svg-icon nav-icon d-flex justify-content-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="10px" height="10px" fill="currentColor" class="bi bi-circle" viewBox="0 0 16 16">
                                        <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                                      </svg>
                                </span>
                                <span class="nav-text">Stores</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>

            @endrole
            @role('Admin')

            <li class="nav-item
            {{ (request()->is('payment')) ? 'active' : '' }}
            {{ (request()->is('account/1')) ? 'active' : '' }}
            {{ (request()->is('account')) ? 'active' : '' }}
            {{ (request()->is('expenses')) ? 'active' : '' }}
            ">
                <a  class="nav-link" data-toggle="collapse" href="#payment" role="button"
                aria-expanded="false" aria-controls="stock">
                    <span class="svg-icon nav-icon">
                        <i class="fas fa-file-invoice-dollar font-size-h4"></i>
                    </span>
                    <span class="nav-text">Finance</span>
                    <i class="fas fa-chevron-right fa-rotate-90"></i>
                </a>
                <div class="collapse nav-collapse
                    {{ (request()->is('payment')) ? 'show' : '' }}
                    {{ (request()->is('account')) ? 'show' : '' }}
                    {{ (request()->is('account/1')) ? 'show' : '' }}
                    {{ (request()->is('expenses')) ? 'show' : '' }}
                    " id="payment" data-parent="#accordion">
                    <ul class="nav flex-column">

                        <li class="nav-item {{ (request()->is('account')) ? 'sub-active' : '' }}">
                            <a href="/account" class="nav-link sub-nav-link {{ (request()->is('account')) ? 'active' : '' }}">
                                <span class="svg-icon nav-icon d-flex justify-content-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="10px" height="10px" fill="currentColor" class="bi bi-circle" viewBox="0 0 16 16">
                                        <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                                      </svg>
                                </span>
                                <span class="nav-text">Cash Account</span>
                            </a>
                        </li>
                        <li class="nav-item {{ (request()->is('expenses')) ? 'sub-active' : '' }}">
                            <a href="/expenses" class="nav-link sub-nav-link {{ (request()->is('expenses')) ? 'active' : '' }}">
                                <span class="svg-icon nav-icon d-flex justify-content-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="10px" height="10px" fill="currentColor" class="bi bi-circle" viewBox="0 0 16 16">
                                        <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                                      </svg>
                                </span>
                                <span class="nav-text">Expenses</span>
                            </a>
                        </li>

                        <li class="nav-item {{ (request()->is('payment')) ? 'sub-active' : '' }}">
                            <a href="/payment" class="nav-link sub-nav-link {{ (request()->is('payment')) ? 'active' : '' }}">
                                <span class="svg-icon nav-icon d-flex justify-content-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="10px" height="10px" fill="currentColor" class="bi bi-circle" viewBox="0 0 16 16">
                                        <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                                      </svg>
                                </span>
                                <span class="nav-text">Supplier Invoices</span>
                            </a>
                        </li>

                    </ul>
                </div>
            </li>

            <li class="nav-item
            {{ (request()->is('customers-list')) ? 'active' : '' }}
            {{ (request()->is('suppliers')) ? 'active' : '' }}
            {{ (request()->is('customershow/')) ? 'active' : '' }}">
                <a  class="nav-link" data-toggle="collapse" href="#people" role="button"
                aria-expanded="false" aria-controls="sales">
                    <span class="svg-icon nav-icon">
                        <span class="fa fa-users"></span>
                    </span>
                    <span class="nav-text">People</span>
                    <i class="fas fa-chevron-right fa-rotate-90"></i>
                </a>
                <div class="collapse nav-collapse
                {{ (request()->is('customers-list')) ? 'show' : '' }}
                {{ (request()->is('customershow/')) ? 'show' : '' }}
                {{ (request()->is('suppliers')) ? 'show' : '' }}
                    " id="people" data-parent="#accordion">
                    <ul class="nav flex-column">

                        <li class="nav-item {{ (request()->is('customers-list')) ? 'sub-active' : '' }}">
                            <a href="/customers-list" class="nav-link sub-nav-link {{ (request()->is('customers-list')) ? 'active' : '' }}">
                                <span class="svg-icon nav-icon d-flex justify-content-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="10px" height="10px" fill="currentColor" class="bi bi-circle" viewBox="0 0 16 16">
                                        <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                                      </svg>
                                </span>
                                <span class="nav-text">Customers</span>
                            </a>
                        </li>

                        <li class="nav-item {{ (request()->is('suppliers')) ? 'sub-active' : '' }}">
                            <a href="/suppliers" class="nav-link sub-nav-link {{ (request()->is('suppliers')) ? 'active' : '' }}">
                                <span class="svg-icon nav-icon d-flex justify-content-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="10px" height="10px" fill="currentColor" class="bi bi-circle" viewBox="0 0 16 16">
                                        <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                                      </svg>
                                </span>
                                <span class="nav-text">Suppliers</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>


<li class="nav-item
{{ (request()->is('report-sales')) ? 'active' : '' }}
{{ (request()->is('report-purchase')) ? 'active' : '' }}
{{ (request()->is('report-item')) ? 'active' : '' }}
{{ (request()->is('filter-sales')) ? 'active' : '' }}
{{ (request()->is('ffilter-item')) ? 'active' : '' }}
{{ (request()->is('stock-reports')) ? 'active' : '' }}
{{ (request()->is('finance')) ? 'active' : '' }}
{{ (request()->is('transaction-report')) ? 'active' : '' }}
{{ (request()->is('transaction-filter')) ? 'active' : '' }}
{{ (request()->is('purchases')) ? 'active' : '' }}
">
    <a  class="nav-link" data-toggle="collapse" href="#Report" role="button"
    aria-expanded="false" aria-controls="Report">
        <span class="svg-icon nav-icon">
            <i class="fas fa-chart-line font-size-h4" ></i>
        </span>
        <span class="nav-text">Reports</span>
        <i class="fas fa-chevron-right fa-rotate-90"></i>
    </a>
    <div class="collapse nav-collapse
    {{ (request()->is('report-sales')) ? 'show' : '' }}
    {{ (request()->is('report-purchase')) ? 'show' : '' }}
    {{ (request()->is('report-item')) ? 'show' : '' }}
    {{ (request()->is('filter-sales')) ? 'show' : '' }}
    {{ (request()->is('filter-item')) ? 'show' : '' }}
    {{ (request()->is('stock-reports')) ? 'show' : '' }}
    {{ (request()->is('finance')) ? 'show' : '' }}
    {{ (request()->is('transaction-report')) ? 'show' : '' }}
    {{ (request()->is('transaction-filter')) ? 'show' : '' }}
    {{ (request()->is('stock-alert')) ? 'show' : '' }}
    {{ (request()->is('purchases')) ? 'show' : '' }}
    " id="Report"  data-parent="#accordion">
        <ul class="nav flex-column">

            <li class="nav-item {{ (request()->is('report-sales')) ? 'sub-active' : '' }}{{ (request()->is('filter-sales')) ? 'sub-active' : '' }}">
                <a href="{{ route('report-sales') }}" class="nav-link sub-nav-link {{ (request()->is('report-sales')) ? 'active' : '' }} {{ (request()->is('filter-sales')) ? 'active' : '' }} ">
                    <span class="svg-icon nav-icon d-flex justify-content-center">
                        <svg xmlns="http://www.w3.org/2000/svg" width="10px" height="10px" fill="currentColor" class="bi bi-circle" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                          </svg>
                    </span>
                    <span class="nav-text">Sales Report</span>
                </a>
            </li>
             <li class="nav-item
                {{ (request()->is('report-purchase')) ? 'sub-active' : '' }}
                {{ (request()->is('filter-sales')) ? 'sub-active' : '' }}
                {{ (request()->is('purchases')) ? 'sub-active' : '' }}">
                <a href="{{ route('report-purchase') }}" class="nav-link sub-nav-link
                {{ (request()->is('report-purchase')) ? 'active' : '' }}
                {{ (request()->is('filter-sales')) ? 'active' : '' }}
                {{ (request()->is('purchases')) ? 'active' : '' }} ">
                    <span class="svg-icon nav-icon d-flex justify-content-center">
                        <svg xmlns="http://www.w3.org/2000/svg" width="10px" height="10px" fill="currentColor" class="bi bi-circle" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                          </svg>
                    </span>
                    <span class="nav-text">Purchase Report</span>
                </a>
            </li>

            <li class="nav-item
            {{ (request()->is('report-item')) ? 'sub-active' : '' }}
            {{ (request()->is('filter-item')) ? 'sub-active' : '' }}
            {{ (request()->is('transaction-report')) ? 'sub-active' : '' }}
            {{ (request()->is('transaction-filter')) ? 'sub-active' : '' }}

            ">
                <a href="{{ route('report-item') }}" class="nav-link sub-nav-link
                {{ (request()->is('report-item')) ? 'active' : '' }}
                {{ (request()->is('filter-item')) ? 'active' : '' }}


                ">
                    <span class="svg-icon nav-icon d-flex justify-content-center">
                        <svg xmlns="http://www.w3.org/2000/svg" width="10px" height="10px" fill="currentColor" class="bi bi-circle" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                          </svg>
                    </span>
                    <span class="nav-text">Sold Items Report</span>
                </a>
            </li>
            <li class="nav-item {{ (request()->is('stock-reports')) ? 'sub-active' : '' }}{{ (request()->is('stock-filter')) ? 'sub-active' : '' }}">
                <a href="/stock-reports" class="nav-link sub-nav-link {{ (request()->is('stock-reports')) ? 'active' : '' }} {{ (request()->is('stock-filter')) ? 'active' : '' }}  ">
                    <span class="svg-icon nav-icon d-flex justify-content-center">
                        <svg xmlns="http://www.w3.org/2000/svg" width="10px" height="10px" fill="currentColor" class="bi bi-circle" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                          </svg>
                    </span>
                    <span class="nav-text">Stock Report</span>
                </a>
            </li>
            <li class="nav-item {{ (request()->is('stock-alert')) ? 'sub-active' : '' }}{{ (request()->is('stock-filter')) ? 'sub-active' : '' }}">
                <a href="/stock-alert" class="nav-link sub-nav-link {{ (request()->is('stock-alert')) ? 'active' : '' }}">
                    <span class="svg-icon nav-icon d-flex justify-content-center">
                        <svg xmlns="http://www.w3.org/2000/svg" width="10px" height="10px" fill="currentColor" class="bi bi-circle" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                          </svg>
                    </span>
                    <span class="nav-text">Stock Alert</span>
                </a>
            </li>

{{--
            <li class="nav-item {{ (request()->is('purchase')) ? 'sub-active' : '' }}">
                <a href="/purchase-report" class="nav-link sub-nav-link {{ (request()->is('purchase')) ? 'active' : '' }}">
                    <span class="svg-icon nav-icon d-flex justify-content-center">
                        <svg xmlns="http://www.w3.org/2000/svg" width="10px" height="10px" fill="currentColor" class="bi bi-circle" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                          </svg>
                    </span>
                    <span class="nav-text">Purchase Stocks</span>
                </a>
            </li> --}}
            <li class="nav-item
            {{ (request()->is('transaction-report')) ? 'sub-active' : '' }}
            {{ (request()->is('transaction-filter')) ? 'sub-active' : '' }}
                ">
                <a href="/transaction-report" class="nav-link sub-nav-link
                {{ (request()->is('transaction-report')) ? 'active' : '' }}
                {{ (request()->is('transaction-filter')) ? 'active' : '' }}
                ">
                    <span class="svg-icon nav-icon d-flex justify-content-center">
                        <svg xmlns="http://www.w3.org/2000/svg" width="10px" height="10px" fill="currentColor" class="bi bi-circle" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                          </svg>
                    </span>
                    <span class="nav-text">Transactions Report</span>
                </a>
            </li>
             <li class="nav-item {{ (request()->is('finance')) ? 'sub-active' : '' }}">
                <a href="/finance" class="nav-link sub-nav-link {{ (request()->is('finance')) ? 'active' : '' }}">
                    <span class="svg-icon nav-icon d-flex justify-content-center">
                        <svg xmlns="http://www.w3.org/2000/svg" width="10px" height="10px" fill="currentColor" class="bi bi-circle" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                          </svg>
                    </span>
                    <span class="nav-text">Finance Report</span>
                </a>
            </li>

        </ul>
    </div>
</li>
            <li class="nav-item
            {{ (request()->is('warehouse')) ? 'active' : '' }}
            {{ (request()->is('shops')) ? 'active' : '' }}
            {{ (request()->is('profile')) ? 'active' : '' }}
            {{ (request()->is('stocks')) ? 'active' : '' }}
            {{ (request()->is('users')) ? 'active' : '' }}
            ">
                <a  class="nav-link" data-toggle="collapse" href="#setting" role="button"
                aria-expanded="false" aria-controls="setting">
                    <span class="svg-icon nav-icon">
                        <i class="fas fa-cogs font-size-h4"></i>
                    </span>
                    <span class="nav-text">Settings</span>
                    <i class="fas fa-chevron-right fa-rotate-90"></i>
                </a>

                <div class="collapse nav-collapse
                {{ (request()->is('warehouse')) ? 'show' : '' }}
                {{ (request()->is('shops')) ? 'show' : '' }}
                {{ (request()->is('profile')) ? 'show' : '' }}
                {{ (request()->is('stocks')) ? 'show' : '' }}
                {{ (request()->is('users')) ? 'show' : '' }}
                " id="setting" data-parent="#accordion">
                    <div id="accordion3">
                        <ul class="nav flex-column">
                            <li class="nav-item {{ (request()->is('profile')) ? 'sub-active' : '' }}">
                                <a href="/profile" class="nav-link sub-nav-link {{ (request()->is('profile')) ? 'active' : '' }}">
                                    <span class="svg-icon nav-icon d-flex justify-content-center">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="10px" height="10px" fill="currentColor" class="bi bi-circle" viewBox="0 0 16 16">
                                            <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                                          </svg>
                                    </span>
                                    <span class="nav-text">Profile</span>
                                </a>
                            </li>

                            <li class="nav-item {{ (request()->is('shops')) ? 'sub-active' : '' }}">
                                <a href="/shops" class="nav-link sub-nav-link {{ (request()->is('shops')) ? 'active' : '' }}">
                                    <span class="svg-icon nav-icon d-flex justify-content-center">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="10px" height="10px" fill="currentColor" class="bi bi-circle" viewBox="0 0 16 16">
                                            <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                                          </svg>
                                    </span>
                                    <span class="nav-text">Shops</span>
                                </a>
                            </li>

                            <li class="nav-item {{ (request()->is('warehouse')) ? 'sub-active' : '' }}">
                                <a href="/warehouse" class="nav-link sub-nav-link {{ (request()->is('warehouse')) ? 'active' : '' }}">
                                    <span class="svg-icon nav-icon d-flex justify-content-center">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="10px" height="10px" fill="currentColor" class="bi bi-circle" viewBox="0 0 16 16">
                                            <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                                          </svg>
                                    </span>
                                    <span class="nav-text">Warehouse</span>
                                </a>
                            </li>
                            <li class="nav-item {{ (request()->is('stocks')) ? 'sub-active' : '' }}">
                                <a href="/stocks" class="nav-link sub-nav-link {{ (request()->is('stocks')) ? 'active' : '' }}">
                                    <span class="svg-icon nav-icon d-flex justify-content-center">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="10px" height="10px" fill="currentColor" class="bi bi-circle" viewBox="0 0 16 16">
                                            <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                                          </svg>
                                    </span>
                                    <span class="nav-text">Items</span>
                                </a>
                            </li>

                            <li class="nav-item {{ (request()->is('users')) ? 'sub-active' : '' }}">
                                <a href="/users" class="nav-link sub-nav-link {{ (request()->is('users')) ? 'active' : '' }}">
                                    <span class="svg-icon nav-icon d-flex justify-content-center">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="10px" height="10px" fill="currentColor" class="bi bi-circle" viewBox="0 0 16 16">
                                            <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                                          </svg>
                                    </span>
                                    <span class="nav-text">Users</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </li>
            @endrole
        </ul>
    </div>

<?php $__env->startSection('content'); ?>

<!--begin::Content-->
<div class="content d-flex flex-column flex-column-fluid" id="tc_content">
    <!--begin::Subheader-->
    <div class="subheader py-2 py-lg-6 subheader-solid">
        <div class="container-fluid">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb bg-white mb-0 px-0 py-2">
                    <li class="breadcrumb-item " aria-current="page">Payment</li>
                    <li class="breadcrumb-item active" aria-current="page">Payment List</li>
                </ol>
            </nav>
        </div>
    </div>
    <!--end::Subheader-->
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-xl-12">
                    <div class="card card-custom gutter-b bg-transparent shadow-none border-0" >
                        <div class="card-header align-items-center   border-bottom-dark px-0">
                            <div class="card-title mb-0">
                                <h3 class="card-label mb-0 font-weight-bold text-body">Pay Out
                                </h3>
                            </div>
                            <div class="icons d-flex">

                                <a href="#" onclick="printDiv()" class="ml-2">
                                    <span class="icon h-30px font-size-h5 w-30px d-flex align-items-center justify-content-center rounded-circle ">
                                        <svg width="15px" height="15px" viewBox="0 0 16 16" class="bi bi-printer-fill" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M5 1a2 2 0 0 0-2 2v1h10V3a2 2 0 0 0-2-2H5z"/>
                                            <path fill-rule="evenodd" d="M11 9H5a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-3a1 1 0 0 0-1-1z"/>
                                            <path fill-rule="evenodd" d="M0 7a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2h-1v-2a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v2H2a2 2 0 0 1-2-2V7zm2.5 1a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1z"/>
                                          </svg>
                                    </span>

                                </a>
                                <a href="#" class="ml-2" >
                                    <span class="icon h-30px font-size-h5 w-30px d-flex align-items-center justify-content-center rounded-circle ">
                                        <svg width="15px" height="15px" viewBox="0 0 16 16" class="bi bi-file-earmark-text-fill" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" d="M2 2a2 2 0 0 1 2-2h5.293A1 1 0 0 1 10 .293L13.707 4a1 1 0 0 1 .293.707V14a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2zm7 2l.5-2.5 3 3L10 5a1 1 0 0 1-1-1zM4.5 8a.5.5 0 0 0 0 1h7a.5.5 0 0 0 0-1h-7zM4 10.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4a.5.5 0 0 1-.5-.5z"/>
                                          </svg>
                                    </span>

                                </a>

                            </div>
                        </div>

                    </div>


                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-xl-12">
                    <div class="card card-custom gutter-b bg-white border-0" >
                        <div class="card-body">
                            <div >
                                <div class="table-responsive" id="printableTable">
                                    <table id="orderTable" class="display" style="width:100%">

                                    <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Supplier Name</th>
                                            <th>Payment Type</th>
                                            <th>Total Tsh.</th>
                                            <th>Paid Tsh.</th>
                                            <th>Outstanding Tsh.</th>
                                            <th>Since</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody class="kt-table-tbody text-dark">
                                        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr class="kt-table-row kt-table-row-level-0
                                        <?php if($payment->amount != $payment->paid+$payment->balance ): ?>text-danger <?php endif; ?>" >
                                            <td><a href="<?php echo e(route('invoices',$payment->id)); ?>"> <?php echo e($payment->id); ?></a></td>
                                            <td><?php echo e($payment->supplier_name); ?></td>
                                            <td>
                                                <?php switch($payment->status):
                                                    case ('Credit'): ?>
                                                    <span class="btn-sm bg-danger text-white ">Credit</span>
                                                        <?php break; ?>

                                                        <?php case ('Cash'): ?>
                                                        <span class="btn-sm bg-success text-white">Cash</span>
                                                        <?php break; ?>
                                                        <?php case ('Installment'): ?>
                                                        <span class="btn-sm bg-warning ">Installment</span>
                                                        <?php break; ?>
                                                        <?php case ('Bank'): ?>
                                                        <span class="btn-sm bg-dark text-white">Bank</span>
                                                        <?php break; ?>
                                                    <?php default: ?>

                                                <?php endswitch; ?>

                                            </td>
                                            <td><?php echo e(number_format($payment->amount)); ?></td>
                                            <td><?php echo e(number_format($payment->paid)); ?></td>
                                            <td><span class="<?php if($payment->balance>0): ?>text-danger <?php endif; ?> <?php if($payment->balance<0): ?>text-success <?php endif; ?>"><?php echo e(number_format($payment->balance)); ?></span></td>
                                            <td><?php echo e(date("d/m/Y", strtotime($payment->created_at))); ?></td>
                                            <td>
                                                <!-- Modal -->
<div class="modal fade" id="issue<?php echo e($payment->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Pay <?php echo e($payment->supplier_name); ?> <br>
            <span class="btn btn-outline-dark">Balance E-wallet <?php echo e(number_format($payment->wallet_balance ?? 0)); ?> </span>
         </h5>


          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <form action="<?php echo e(route('payment.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="row">

                    <div class="col-12">
                        <div class="form-group">
                            <?php if($payment->wallet_balance >= $payment->balance): ?>
                            <span class="form-control text-center" readonly value="Pay via E-wallet"><strong> Tsh. <?php echo e(number_format($payment->balance)); ?></strong></span>
                            <input type="hidden"  name="pay_amount" class="form-control" value="<?php echo e($payment->balance); ?>">
                            <input type="hidden" name="purchase_order_id" class="form-control" value="<?php echo e($payment->id); ?>"  required>
                            <input type="hidden" name="supplier_id" class="form-control" value="<?php echo e($payment->supplier_id); ?>">
                            <input type="hidden" name="wallet_id" class="form-control" value="<?php echo e($payment->wallet_id); ?>">
                            <input type="hidden" name="pay_order" value="pay_order">
                            <input type="submit"  name="pay_wallet" class="form-control bg-dark text-white text-center" readonly value="Pay via E-wallet">
                            <?php elseif($payment->wallet_balance >0): ?>
                            <label class="text-dark" >Amount </label>

                            <input type="hidden" name="supplier_id" class="form-control" value="<?php echo e($payment->supplier_id); ?>">
                            <input type="hidden" name="wallet_id" class="form-control" value="<?php echo e($payment->wallet_id); ?>">
                            <input type="number" name="pay_amount" class="form-control" max="<?php echo e($payment->balance - $payment->wallet_balance); ?>"
                            value="<?php echo e($payment->balance - $payment->wallet_balance); ?>" required>
                            <input type="hidden" name="wallet_patially" class="form-control" value="<?php echo e($payment->wallet_balance); ?>">
                            <input type="hidden" name="purchase_order_id" class="form-control" value="<?php echo e($payment->id); ?>">
                            <input type="hidden" name="wallet" class="form-control" value="<?php echo e($payment->wallet_balance); ?>">
                            <input type="hidden" name="pay_order" value="pay_order">
                            <br>
                            <button type="submit" class="btn btn-success" >Submit</button>
                           <?php else: ?>
                            <label class="text-dark" >Amount </label>
                            <input type="number" name="pay_amount" class="form-control" max="<?php echo e($payment->balance-$payment->wallet_balance); ?>" value="<?php echo e($payment->balance); ?>" required>
                            <input type="hidden" name="purchase_order_id" class="form-control" value="<?php echo e($payment->id); ?>">
                            <input type="hidden" name="wallet" class="form-control" value="<?php echo e($payment->wallet_balance ?? 0); ?>">
                            <input type="hidden" name="pay_order" value="pay_order">
                            <input type="hidden" name="wallet_id" class="form-control" value="<?php echo e($payment->wallet_id); ?>">
                            <br>
                            <button type="submit" class="btn btn-success" >Submit</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

              </form>
        </div>

      </div>
    </div>
  </div>
  


                                                <button type="button" class="btn btn-sm btn-success btn-xs" data-toggle="modal" data-target="#issue<?php echo e($payment->id); ?>">
                                                <i class="fa fa-credit-card"></i> Pay
                                              </button>
                                            </td>

                                        </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                        <?php if($payments != '[]'): ?>
                                        <?php $__currentLoopData = $totals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>

                                            <th></th>
                                            <th></th>
                                            <th>

                                            </th>
                                            <th>
                                                <?php echo e(number_format($total->total_purchase)); ?>

                                            </th>
                                            <th>
                                                <?php echo e(number_format($total->total_paid)); ?>

                                            </th>
                                            <th>
                                                <?php echo e(number_format($total->total_balance)); ?>

                                            </th>
                                            <th></th>
                                            <th> </th>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </tfoot>
                                </table>
                            </div>
                        </div>


                    </div>
                </div>


            </div>
        </div>

    </div>

</div>

</div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moxacotz/public_html/zagamba/resources/views/admin/payments/payment.blade.php ENDPATH**/ ?>
<?php

use App\Http\Controllers\accountController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\adminController;
use App\Http\Controllers\companyValueController;
use App\Http\Controllers\customerController;
use App\Http\Controllers\customRegisterController;
use App\Http\Controllers\expensesController;
use App\Http\Controllers\paymentController;
use App\Http\Controllers\posController;
use App\Http\Controllers\profileController;
use App\Http\Controllers\purchaseController;
use App\Http\Controllers\rentalController;
use App\Http\Controllers\reportController;
use App\Http\Controllers\reportFinanceController;
use App\Http\Controllers\reportStockController;
use App\Http\Controllers\roleController;
use App\Http\Controllers\salesController;
use App\Http\Controllers\stockController;
use App\Http\Controllers\stockingController;
use App\Http\Controllers\storeController;
use App\Http\Controllers\supplierController;
use App\Http\Controllers\tenantController;
use App\Http\Controllers\testerController;
use App\Http\Controllers\usersPermissionController;
use App\Http\Controllers\warehouseController;
use \Spatie\Multitenancy\Http\Middleware\NeedsTenant;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Authenticated area
Route::get('create-company',[tenantController::class,'index'])->name('create-company');
Route::get('/license', [adminController::class,'license']);
// Route::middleware(['tenant','auth'])->group(function() {
    // routes

Route::middleware(['auth'])->group(function () {
    Route::get('/', function () {
        return redirect()->route('admin.index');
    });
Route::resource('companyvalue',companyValueController::class);
Route::resource('admin', adminController::class);
Route::resource('warehouse', warehouseController::class)->middleware(['role:Admin']);
Route::resource('users', usersPermissionController::class)->middleware(['role:Admin']);
Route::resource('suppliers', supplierController::class)->middleware(['role:Admin']);
Route::resource('stocks', stockController::class)->middleware(['role:Admin|Store']);
Route::resource('pos', posController::class)->middleware(['role:Sales']);
Route::resource('customers', customerController::class);
Route::resource('stocking', stockingController::class);
Route::get('my-stock', [stockingController::class,'my_stock'])->middleware(['role:Sales']);
Route::resource('sales', salesController::class);
Route::get('outstandings', [salesController::class,'outstanding']);
Route::resource('payment', paymentController::class);
Route::get('invoices/{id}', [paymentController::class,'viewInvoice'])->name('invoices');
Route::get('order', [salesController::class,'order'])->name('order','order');
Route::post('orders',[posController::class,'orders'])->name('orders','orders');

route::resource('/roles',roleController::class)->middleware(['role:Admin']);
route::resource('/expenses',expensesController::class)->middleware(['role:Admin']);
route::resource('/stores',storeController::class)->middleware(['role:Admin|Store']);
route::resource('/account',accountController::class)->middleware(['role:Admin']);
route::resource('/stock-purchase',purchaseController::class)->middleware(['role:Admin|Store']);
Route::get('customers-list', [customerController::class,'customer_list']);

// Sales Report Controllers
Route::get('report-sales',[reportController::class,'index'])->name('report-sales');
Route::get('report-purchase',[reportController::class,'purchaseReport'])->name('report-purchase');
Route::get('report-item',[reportController::class,'itemSold'])->name('report-item');
Route::get('filter-item',[reportController::class,'soldFilter'])->name('filter-item');
Route::get('show-order/{id}',[reportController::class,'showOrder'])->name('show-order');
Route::get('show-purchase/{id}',[reportController::class,'showPurchase'])->name('show-purchase');
Route::get('filter-sales',[reportController::class,'filtersales'])->name('filter-sales');
Route::get('purchases',[reportController::class,'filterPurchase'])->name('purchases');
Route::get('customersales/{id}',[reportController::class,'customersale'])->name('customersales');

Route::resource('report-action', reportController::class);

// Stock Report Controllers
Route::resource('stock-reports', reportStockController::class);
Route::get('stock-alert',[reportStockController::class,'stock_alert'])->name('stock-reports');
Route::resource('finance', reportFinanceController::class);
Route::get('filter-finance', [reportFinanceController::class,'filterfinance'])->name('filter-finance');
Route::get('customershow/{id}',[customerController::class,'customershow'])->name('customershow');
Route::get('/substore/{id}/{item}',[storeController::class, 'show'])->name('substore')->middleware(['role:Admin|Store']);
Route::get('/purchase-report',[reportFinanceController::class, 'purchaseReport'])->name('purchase-report');
Route::get('/filter-purchase',[reportFinanceController::class, 'purchaseFilter'])->name('filter-purchase');

Route::get('sold/{id}',[reportFinanceController::class, 'sold'])->name('sold');
Route::get('instock/{id}',[reportFinanceController::class, 'instock'])->name('instock');

Route::get('transaction-report',[reportController::class,'transaction_report'])->name('transaction-report');
Route::get('transactions/{id}',[reportController::class,'transactions'])->name('transactions');
Route::get('transaction-filter',[reportController::class,'transaction_filter'])->name('transaction-filter');

Route::middleware(['auth:sanctum', 'verified'])->get('/dashboard', function () {
    return redirect()->route('admin.index');
})->name('dashboard');

// Rental

Route::resource('stock-rent', rentalController::class);
Route::get('rent-items', [rentalController::class,'rental_items']);
Route::post('addrentItem', [rentalController::class,'addRentItem'])->name('addrentItem');
Route::post('createOrder', [rentalController::class,'createOrder'])->name('createOrder');
Route::get('shops',[warehouseController::class,'shops']);
Route::resource('profile',profileController::class);

Route::resource('custom-users', customRegisterController::class);


// test
Route::get('tester',[testerController::class,'test']);
});

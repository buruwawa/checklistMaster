<?php $__env->startSection('content'); ?>
				<!--begin::Content-->
				<div class="content d-flex flex-column flex-column-fluid" id="tc_content">
					<!--begin::Subheader-->
					<div class="subheader py-2 py-lg-6 subheader-solid">
						<div class="container-fluid">
							<nav aria-label="breadcrumb">
								<ol class="breadcrumb bg-white mb-0 px-0 py-2">
									<li class="breadcrumb-item active" aria-current="page">Purchase Stocks</li>
								</ol>
							</nav>
						</div>
					</div>
					<!--end::Subheader-->
					<!--begin::Entry-->
					<div class="d-flex flex-column-fluid">
						<!--begin::Container-->
						<div class="container-fluid">
							<div class="row">
								<div class="col-12">
									<div class="row">
										<div class="col-lg-12 col-xl-12">
											<div class="card card-custom gutter-b bg-transparent shadow-none border-0" >
												<div class="card-header align-items-center  border-bottom-dark px-0">
													<div class="card-title mb-0">
														<h3 class="card-label mb-0 font-weight-bold text-body text-right">
														</h3>
													</div>

												</div>

											</div>


										</div>
									</div>


		<div class="contentPOS">
	    <div class="container-fluid">
			<div class="row">

				<div class="col-xl-9 col-lg-8 col-md-8">
				     <div class="">
						<div class="card card-custom gutter-b bg-white border-0 table-contentpos">
							<div class="card-body">
								<div class="d-flex  colorfull-select">


                                    
                                    <div class="col-md-8">
                                        <div class="greeting-text">
                                        <h3 class="card-label mb-0 ">
                                           Order Code:#<?php echo e($id); ?> </h3>
                                          <h6> Purchase from: <?php if(empty($suppliers->supplier_name)): ?>
                                           <script type="text/javascript">
                                            window.location = "<?php echo e(url('/pos')); ?>";
                                        </script>
                                           <?php else: ?>
                                           <?php echo e($suppliers->supplier_name); ?>

                                          <?php endif; ?>
                                        </h6>

								</div>
								</div>
                                
 
                                    <div class="col-md-4">

                                        <label class="text-dark d-flex" >Select items to sell</label>
                                        <div class="form-group">
                                    <form action="<?php echo e(route('stock-purchase.store')); ?>" method="POST">
                                         <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($id); ?>">

                                        <select class="arabic-select  form-control" onchange="this.form.submit()" name="item_id" required>
                                            <option value="" selected disabled>-- Select Item --</option>
                                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->item); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </form>
                                    </div>
								</div>
                                


								</div>
							</div>
						</div>
                        <?php if($order_items != '[]'): ?>
						<div class="card card-custom gutter-b bg-white border-0 table-contentpos">
                            <form action="<?php echo e(route('stock-purchase.update',$id)); ?>" method="POST">
                                 <input type="hidden" name="_method" value="PUT">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
								<div class="container" style="padding-top:20px; padding-bottom:20px;">
									<div class="table-responsive" id="">
										<table id="orderTable" class="display" style="width:100%">
											<thead>
												<tr>

                                                    <th>Name</th>
													<th>Quantity</th>
													<th>Unit Price</th>
													<th>Subtotal</th>

												</tr>
											</thead>
											<tbody>
                                                <?php $__currentLoopData = $order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<tr>

													<td><?php echo e($orderitem->item); ?></td>
													<td>
                                                        <input name="item_id[]" type="hidden" value="<?php echo e($orderitem->id); ?>">
														<input name="qty[]" type="number" min="1" class="form-control border-dark w-100px" id="basicInput2" placeholder="" value="<?php echo e($orderitem->qty); ?>" >
													</td>
													<td> <?php echo e($orderitem->price); ?>

                                                        </td>
													<td><?php echo e(number_format($orderitem->price * $orderitem->qty)); ?></td>

												</tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</tbody>
                                            <tfoot>

                                                <th></th>
                                                <th></th>
                                                <th>Total Tsh.</th>
                                                <th> <?php $__currentLoopData = $pos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $por): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e(number_format($por->subtotal)); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></th>
                                        </tfoot>
										</table>
									</div>
                                    <hr>


                                    <div class="form-group row mb-0">

										<div class="col-md-6 btn-submit d-flex ">

                                            <button type="button" class="btn btn-secondary white" data-toggle="modal" data-target="#edit">
                                             <i class="fa fa-trash"></i>   Delete Items
                                            </button>
                                        </div>
                                        <div class="col-md-6 btn-submit d-flex justify-content-end">

											<button type="submit" class="btn btn-success white " name="draft" value="save draft">
												<svg xmlns="http://www.w3.org/2000/svg"  fill="currentColor" class="bi bi-folder-fill svg-sm mr-2" viewBox="0 0 16 16">
													<path d="M9.828 3h3.982a2 2 0 0 1 1.992 2.181l-.637 7A2 2 0 0 1 13.174 14H2.826a2 2 0 0 1-1.991-1.819l-.637-7a1.99 1.99 0 0 1 .342-1.31L.5 3a2 2 0 0 1 2-2h3.672a2 2 0 0 1 1.414.586l.828.828A2 2 0 0 0 9.828 3zm-8.322.12C1.72 3.042 1.95 3 2.19 3h5.396l-.707-.707A1 1 0 0 0 6.172 2H2.5a1 1 0 0 0-1 .981l.006.139z"/>
												  </svg>
												Draft Order
											</button>
										</div>
									</div>



								</div>
                            </form>
						</div>
                        <?php endif; ?>
					 </div>
				 </div>
                 <?php if($order_items != '[]'): ?>
				 <div class="col-xl-3 col-lg-4 col-md-4">
					 <div class="card card-custom gutter-b bg-white border-0">
                         <form action="<?php echo e(route('stock-purchase.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
						<div class="card-body" >
							<div class="shop-profile">
								<div class="media">

									<div class="media-body ml-3">
										<h3 class="title font-weight-bold">Purchase Order </h3>

									</div>
								</div>
							</div>
							<div class="resulttable-pos">
								<table class="table right-table">

									<tbody>
                                        <?php $__currentLoopData = $pos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $po): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


									  <tr class="d-flex align-items-center justify-content-between">
										<th class="border-0 font-size-h5 mb-0 font-size-bold text-dark">
												Total Items
										</th>
										<td class="border-0 justify-content-end d-flex text-dark font-size-base"><?php echo e($po->order_qty); ?></td>

									  </tr>
									  <tr class="d-flex align-items-center justify-content-between">
										<th class="border-0 font-size-h5 mb-0 font-size-bold text-dark">
												Subtotal <span class="text-danger">- (VAT)</span>
										</th>
										<td class="border-0 justify-content-end d-flex text-dark font-size-base">Tsh. <?php echo e(number_format($po->subtotal - $po->vat)); ?></td>

									  </tr>

									  <tr class="d-flex align-items-center justify-content-between">
										<th class="border-0 font-size-h5 mb-0 font-size-bold text-dark">
												VAT

										</th>
										<td class="border-0 justify-content-end d-flex text-dark font-size-base">Tsh <?php echo e(number_format($po->vat)); ?></td>

									  </tr>


									  <tr class="d-flex align-items-center justify-content-between item-price">
										<th class="border-0 font-size-h5 mb-0 font-size-bold text-primary">

												TOTAL
										</th>
										<td class="border-0 justify-content-end d-flex text-primary font-size-base">Tsh. <?php echo e(number_format($po->subtotal - $po->discount)); ?> </td>

									  </tr>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								  </table>
							 </div>
                             <label for="" class="font-size-bold"> Mode of Payment* </label>
                             <select name="status" id="pay" class="form-control" onchange="return showInstallment()" required>
                                <option value="" disabled selected> -- Select Payment mode --</option>
                                <option>Cash</option>
                                <option>Credit</option>
                                <option>Installment</option>

                             </select>
                             <div id="installment" style="visibility:hidden" >
                                <label for="" class="font-size-bold">Enter Amount</label>
                                <input type="number" name="installment" class="form-control bg-info text-white" value="<?php echo e($po->subtotal - $po->discount); ?>">
                            </div>
                             <hr>
							 <div class="d-flex justify-content-end align-items-center flex-column">
                                    <input type="hidden" name="warehouse_id"  value="<?php echo e($suppliers->warehouse_id); ?>">
                                    <input type="hidden" name="order_id"  value="<?php echo e($id); ?>">
                                    <input type="hidden" name="vat" value="<?php echo e($po->vat); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($po->subtotal - $po->discount); ?>">
									<input type="submit" class="btn btn-primary white mb-2" name="purchase_now"  value="Submit">
							 </div>
						</div>
                    </form>
					 </div>
				 </div>
                 <?php endif; ?>
			</div>
		</div>
   </div>

<!-- start of delete Modal -->
  <div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Delete items from this order</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <div class="resulttable-pos">
            <table id="orderTable" class="display" style="width:100%">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th class=" text-right no-sort"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($orderitem->id); ?></td>
                        <td><?php echo e($orderitem->item); ?></td>

                        <td>
                        <form action="<?php echo e(route('stock-purchase.destroy',$orderitem->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="_method" value="delete">
                            <div class="card-toolbar text-right">
                                <input type="hidden" name="order_id" value="<?php echo e($orderitem->id); ?>">
                            <button class="btn-sm btn btn-danger" title="Delete" type="submit" name="delete" value="delet this item"><i class="fas fa-trash-alt"></i></button>
                            </div>
                        </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </tbody>
            </table>
        </div>
        </div>

      </div>
    </div>
  </div>
  


								</div>
							</div>
						</div>


					</div>

				</div>

<script>
       // installment calc.
       function showInstallment(){
        var selectBox = document.getElementById('pay');
        var userInput = selectBox.options[selectBox.selectedIndex].value;
        if(userInput =='Installment'){
            document.getElementById('installment').style.visibility='visible';
        }
        else{
            document.getElementById('installment').style.visibility='hidden';
        }
    }
</script>



</body>
<!--end::Body-->

</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moxacotz/public_html/zagamba/resources/views/admin/stocking/show-purchase.blade.php ENDPATH**/ ?>
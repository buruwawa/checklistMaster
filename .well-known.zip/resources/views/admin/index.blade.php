@extends('layouts.app')
@section('content')

    <!--begin::Content-->
    <div class="content d-flex flex-column flex-column-fluid" id="tc_content">
        <!--begin::Subheader-->
        <div class="subheader py-2 py-lg-6 subheader-solid">
            <div class="container-fluid">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb bg-white mb-0 px-0 py-2">
                        <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                    </ol>
                </nav>
            </div>
        </div>
        <!--end::Subheader-->
        <!--begin::Entry-->
        <div class="d-flex flex-column-fluid">
            <!--begin::Container-->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        @role('Admin|Sales')
                        <div class="row">

                            <div class="col-lg-6 col-xl-4">
                                <div class="card card-custom gutter-b bg-white border-0 theme-circle theme-circle-primary">

                                    <div class="card-body">
                                        <h3 class="text-body font-weight-bold">Daily Sales</h3>

                            <div class="mt-3">
                                <div class="d-flex align-items-center">
                                    <span class="text-dark font-weight-bold font-size-h1 mr-3">
                                        Tsh. <span
                                            class="" data-target="400">
                                        {{ number_format(  $thedaily->daily_sales+$collection_daily) }}</span>
                                    </span>
                                </div>
                                <div class="text-black-50 mt-3"><span class="btn-sm bg-success">
                                    <a href="{{ route('transactions','daily') }}"> <span class="text-white">Cash Tsh.
                                        {{ number_format(  $thedaily->daily_cash) }} </span></a>
                                </span> &nbsp;
                                <span class="btn-sm bg-primary text-white">Payment Tsh. {{ number_format( $collection_daily) }}</span><br>
                                <span class="btn-sm bg-danger"><a href="#">
                                    <span class="text-white"> Credit Tsh. {{ number_format($thedaily->daily_balance) }} </span>
                                </a>
                            </span>

                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-xl-4">
                                <div class="card card-custom gutter-b bg-white border-0 theme-circle theme-circle theme-circle-secondary">

                                    <div class="card-body">
                                        <h3 class="text-body font-weight-bold">Weekly Sales</h3>

                                        <div class="mt-3">
                                            <div class="d-flex align-items-center">
                                                <span class="text-dark font-weight-bold font-size-h1 mr-3">Tsh. <span
                                                        class="" data-target="6000">
                                                    {{ number_format($theweekly->weekly_sales+$collection_weekly) }}</span></span>
                                            </div>
                                            <div class="text-black-50 mt-3"><span class="btn-sm bg-success">
                                                <a href="{{ route('transactions','weekly') }}"> <span class="text-white">Cash Tsh. {{ number_format($theweekly->weekly_cash) }}  </span></a>
                                            </span> &nbsp;
                                            <span class="btn-sm bg-primary text-white">Payment Tsh. {{ number_format( $collection_weekly) }}</span><br>

                                            <span class="btn-sm bg-danger">
                                                <a href="#"> <span class="text-white"> Credit Tsh. {{ number_format($theweekly->weekly_balance) }} </span></a></span>

                                            </div>
                                        </div>


                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-xl-4">
                                <div class="card card-custom gutter-b bg-white border-0 theme-circle theme-circle-success">

                                    <div class="card-body">
                                        <h3 class="text-body font-weight-bold">Monthly Sales</h3>

                                        <div class="mt-3">
                                            <div class="d-flex align-items-center">
                                                <span class="text-dark font-weight-bold font-size-h1 mr-3">
                                                    <span >Tsh.
                                                    {{ number_format($themonthly->monthly_sales+$collection_monthly) }}</span></span>
                                            </div>
                                            <div class="text-black-50 mt-3"><span class="btn-sm bg-success">
                                                <a href="{{ route('transactions','monthly') }}"> <span class="text-white">Cash Tsh.
                                                    {{ number_format($themonthly->monthly_cash) }}
                                                </span></a>
                                            </span> &nbsp;
                                            <span class="btn-sm bg-primary text-white">Payment Tsh. {{ number_format( $collection_monthly) }}</span><br>

                                            <span class="btn-sm bg-danger">
                                                <a href="#"> <span class="text-white"> Credit Tsh.  {{ number_format($themonthly->monthly_balance) }}</span></a></span>


                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @isset($pending_orders )

                            <div class="col-lg-6 col-xl-4">
                                <div class="card card-custom gutter-b bg-white border-0 theme-circle theme-circle-success">

                                    <div class="card-body">
                                        <h3 class="text-body font-weight-bold">Pending Orders</h3>

                                        <div class="mt-3">
                                            <div class="d-flex align-items-center">
                                                <span class="text-dark font-weight-bold font-size-h1 mr-3">
                                                    <span> <a href="/order">
                                                        {{ $pending_orders }}
                                                    </a> </span>
                                                </span>
                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>
                            @endisset
                        </div>
                        @endrole
                        @role('')
                        <div class="alert alert-info">You don't have permission, kindly contact system admin</div>
                        @endrole
                    </div>

                </div>
            </div>

        </div>

    </div>



    @endsection


